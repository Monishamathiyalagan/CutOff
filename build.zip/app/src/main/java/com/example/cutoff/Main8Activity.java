package com.example.cutoff;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Main8Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
    }

    public void bcaClick(View view) {
        Intent intent=new Intent(this,Main9Activity.class);
        startActivity(intent);

    }

    public void bcomClick(View view) {
        Intent intent=new Intent(this,Main10Activity.class);
        startActivity(intent);

    }

    public void bscClick(View view) {
        Intent intent=new Intent(this,Main11Activity.class);
        startActivity(intent);
    }

    public void bbaClick(View view) {
        Intent intent=new Intent(this,Main12Activity.class);
        startActivity(intent);
    }

    public void baClick(View view) {
        Intent intent=new Intent(this,Main13Activity.class);
        startActivity(intent);
    }

    public void backClick(View view) {
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
